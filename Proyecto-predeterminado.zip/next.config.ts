import type { NextConfig } from "next";

const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

const nextConfig: NextConfig = {
  output: "export",
  basePath,
  assetPrefix: basePath === "" ? undefined : basePath,
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;